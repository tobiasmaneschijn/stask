
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'tobiasmaneschijn',
  applicationName: 'staskcustomtoken',
  appUid: 'KzQLPyjwmHTkYCmMKk',
  orgUid: 'c3d2a160-7378-4051-9edf-b9df12e71ce9',
  deploymentUid: 'efb4e9c0-4cd5-4645-87af-479d0904ecd2',
  serviceName: 'firebase-custom-token',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'firebase-custom-token-dev-auth', timeout: 6 };

try {
  const userHandler = require('./src/handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}