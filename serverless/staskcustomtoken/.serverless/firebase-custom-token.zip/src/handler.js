const admin = require("firebase-admin");
const jwtDecode = require("jwt-decode");
const serviceAccount = require("./k.json");

let app = null;
const getCustomToken = async (sub) => {
  if (app === null) {
    app = admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
    });
  }

  const firebaseToken = await admin.auth().createCustomToken(sub);
  return firebaseToken;
};

const setCustomTokenFirebase = async (event) => {
  const { headers } = event;
  const { Authorization } = headers;
  const jtwToken = Authorization.split("Bearer")[1];
  const jwtDecoded = jwtDecode(jtwToken);
  const token = await getCustomToken(jwtDecoded["sub"]);
  return { token };
};

module.exports.handler = async (event) => {
  return {
    statusCode: 200,
    headers: {
      "Access-Control-Allow-Origin": "*", // Required for CORS support to work
      "Access-Control-Allow-Credentials": true, // Required for CORS support to work
    },
    body: JSON.stringify(
      {
        data: {
          token: await setCustomTokenFirebase(event),
        },
      },
      null,
      2
    ),
  };
};
